#include "Button_Driver.h"
#include "bsw.h"



int read_LCD_buttons(void)
{
    unsigned adc_key_in;
    int button_state;
    button_state = readADCValue(BUTTON_CH);

    //adc_key_in = readADCValue(BUTTON_CH);
    if (adc_key_in < 50) {//  push button "RIGHT" and show the word on the screen 
        button_state = btnRIGHT;
     
    } 
    else if (adc_key_in < 250){ 
        button_state = btnLEFT; //  push button "LEFT" and show the word on the screen 
       
    }     
    else if (adc_key_in < 450){ 
        button_state = btnUP; //  push button "UP" and show the word on the screen 
       
    } 
    else if (adc_key_in < 650){ 
        button_state = btnDOWN; //  push button "DOWN" and show the word on the screen 
      
    } 
    else if (adc_key_in < 850){ 
        button_state = btnSELECT;  //  push button "SELECT" and show the word  on the screen 
        
    } 
    else if (adc_key_in >= 50){ 
        button_state = btnNONE;  //  No action  will show "None" on the screen 
       
    } 
    return button_state;
}