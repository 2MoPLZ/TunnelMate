#ifndef BUTTON_H
#define BUTTON_H

#include "illd\src\ConfigurationIsr.h"
#include "illd\src\Configuration.h"

#define BUTTON_CH 3

#define btnRIGHT  0 
#define btnUP     1 
#define btnDOWN   2 
#define btnLEFT   3 
#define btnSELECT 4 
#define btnNONE   5 

int read_LCD_buttons();

#endif // LCD_H